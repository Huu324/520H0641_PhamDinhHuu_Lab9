using StudentServiceLib;
namespace _520H0641_Lab9
{
    [TestClass]
    public class StudentTest
    {
        [TestMethod]
        public void Testcase1()
        {
            Student s = new Student();
            s.Score = 8.5;
            char letter = s.getLetterScore();

            Assert.AreEqual('A', letter);
        }
        [TestMethod]
        public void Testcase2()
        {
            Student s = new Student();
            s.Score = 8;
            char letter = s.getLetterScore();

            Assert.AreEqual('A', letter);
        }
        [TestMethod]
        public void Testcase3()
        {
            Student s = new Student();
            s.Score = 7;
            char letter = s.getLetterScore();

            Assert.AreEqual('C', letter);
        }
        [TestMethod]
        public void Testcase4()
        {
            Student s = new Student();
            s.Score = 5.5;
            char letter = s.getLetterScore();

            Assert.AreEqual('C', letter);
        }

    }
}